// Fonction pour afficher la boîte modale
function afficherBoiteModale() {
    var modal = document.getElementById('myModal');
    modal.style.display = 'block';
}

// Fonction pour fermer la boîte modale
function fermerBoiteModale() {
    var modal = document.getElementById('myModal');
    modal.style.display = 'none';
}


// Liste des noms de fichiers d'images dans le dossier "images/" et leurs vitesses associées
const imagesData = [
    { src: 'canette.png', vitesse: 2 },
    { src: 'maltesers.png', vitesse: 3 },
    { src: 'pneu.png', vitesse: 1 },
    // Ajoutez d'autres noms d'images et leurs vitesses au besoin
];

// Compteur
var compteur = 0;

// Variable pour suivre l'état du clic
var clicEnCours = false;


// Fonction pour générer une image aléatoire
function genererImage() {
    var img = document.createElement('img');

    // Sélectionner une image aléatoire depuis la liste
    var imageData = imagesData[Math.floor(Math.random() * imagesData.length)];
    img.src = 'images/dechets/' + imageData.src; // Assurez-vous que le dossier "images/" contient vos images

    document.getElementById('image-container').appendChild(img);

    // Position initiale aléatoire en haut de la page
    var positionX = Math.random() * window.innerWidth*0.75;
    img.style.left = positionX + 'px';
    img.style.top = '0px';

    // Ajouter la vitesse de l'image comme propriété de style personnalisée
    img.style.setProperty('--vitesse', imageData.vitesse);

    // Ajout du gestionnaire d'événements pour le clic sur l'image
    img.addEventListener('click', function() {
        img.remove(); // Supprimer l'image lorsqu'elle est cliquée
        compteur++; // Incrémenter le compteur
        document.getElementById('compteur').textContent = compteur; // Mettre à jour l'affichage du compteur
    });

    // Déplacement vers le bas avec une vitesse personnalisée
    function deplacerImage() {
        var positionY = parseInt(img.style.top);
        img.style.top = positionY + imageData.vitesse + 'px';

        // Vérifier si l'image a atteint le bas de la page
        if (positionY + 102 > window.innerHeight) {
            img.remove(); // Supprimer l'image une fois qu'elle a atteint le bas
        } else {
            requestAnimationFrame(deplacerImage);
        }
    }

    // Lancer le déplacement
    deplacerImage();
}


// Générer une nouvelle image toutes les X millisecondes (ajustez selon vos besoins)
setInterval(genererImage, 1000);
